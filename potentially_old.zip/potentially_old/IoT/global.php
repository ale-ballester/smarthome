<?php
    
    // Everything here will be required in every single script (check autoload)
    
    // These are global constants used to 'build up' route names to require files
    define('DS', DIRECTORY_SEPARATOR);
    define('ROOT', realpath(dirname(__FILE__)) . DS);
    define('URL', "https://smarthome-ale-ballester.c9users.io/");

?>