<?php namespace Models;

class User
{
    
    private $name;
    private $email;
    private $password;
    private $devices = [
        'id' => [],
        'type' => [],
        'name' => [],
        'status' => [],
        'action' => [],
    ];
    
    private $conn;
    
    public function __construct()
    {
        $this->conn = new Connection();
    }
    
    public function set($attr, $content)
    {
        $this->$attr = $content;
    }
    
    public function get($attr)
    {
        return $this->$attr;
    }
    
    public function register($name, $email, $password)
    {
        $sql = "SELECT email FROM users WHERE email = '$email'";
        $result = $this->conn->returnQuery($sql);
        $row = mysqli_fetch_assoc($result);
        if(!$row['email']) {
            $sql = "INSERT INTO users (name, email, password) VALUES ('$name',  '$email', '$password')";
            $this->conn->simpleQuery($sql);
            return true;
        }
        return false;
    }
    
    public function validate($user, $pass)
    {
        $sql = "SELECT name, password FROM users WHERE email = '$user'";
        $result = $this->conn->returnQuery($sql);
        $row = mysqli_fetch_assoc($result);
        if ($row['password'] == $pass) {
            $this->name = $row['name'];
            $this->email = $user;
            $this->password = $row['password'];
            return array(
                'name' => $this->name,
                'email' => $this->email,
                'password' => $this->password,
            );
        }
        return false;
    }
    
    public function getPass()
    {
        $sql = "SELECT password FROM users WHERE email = '{$this->email}'";
        $result = $this->conn->returnQuery($sql);
        $row = mysqli_fetch_assoc($result);
        return $row['password'];
    }
    
    public function changePassword($pass)
    {
        $sql = "UPDATE users SET password = '$pass' WHERE email = '{$this->email}'";
        $this->conn->simpleQuery($sql);
    }
    
    public function getDevices(){
        $sql = "SELECT device, name FROM device_user WHERE user = '{$this->email}'";
        $result = $this->conn->returnQuery($sql);
        for($i = 0; $row = mysqli_fetch_assoc($result); $i++) {
            $this->devices['id'][$i] = $row['device'];
            $this->devices['name'][$i] = $row['name'];
        }
        return $this->devices;
    }
    
    public function nameDevice($id, $name)
    {
        $sql = "SELECT id FROM devices WHERE id = '$id'";
        $result = $this->conn->returnQuery($sql);
        $row = mysqli_fetch_assoc($result);
        if ($row['id']) {
            $sql = "INSERT INTO device_user (user, device, name) VALUES ('{$this->email}', '$id', '$name')";
            $this->conn->simpleQuery($sql);
            return true;
        }
        return false;
    }
}

?>