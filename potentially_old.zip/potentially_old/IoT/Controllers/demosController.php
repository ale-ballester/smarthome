<?php namespace Controllers;

class demosController
{
    public function onoff()
    {
        
    }
}