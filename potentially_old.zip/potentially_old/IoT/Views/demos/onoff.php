<head>
<style type="text/css">
html, body{width: 100%; height: 100%; padding: 0; margin: 0}
body {background-image: url('<?php echo URL; ?>Views/img/demos/co.png'); background-repeat: repeat-y repeat-x; position: absolute; border: 0px;}
#cont {
  position: absolute;
  top:50%;
  left:50%;
  -ms-transform: translateX(-50%) translateY(-50%);
  -webkit-transform: translate(-50%,-50%);
  transform: translate(-50%,-50%);
}   
.onoffswitch {
    position: relative; width: 200px;
    -webkit-user-select:none; -moz-user-select:none; -ms-user-select: none;
}
.onoffswitch-checkbox {
    display: none;
}
.onoffswitch-label {
    display: block; overflow: hidden; cursor: pointer;
    border: 2px solid #999999; border-radius: 50px;
}
.onoffswitch-inner {
    display: block; width: 200%; margin-left: -100%;
    transition: margin 0.3s ease-in 0s;
}
.onoffswitch-inner:before, .onoffswitch-inner:after {
    display: block; float: left; width: 50%; height: 75px; padding: 0; line-height: 75px;
    font-size: 14px; color: white; font-family: Trebuchet, Arial, sans-serif; font-weight: bold;
    box-sizing: border-box;
}
.onoffswitch-inner:before {
    content: "ON";
    padding-left: 10px;
    background-color: #09E832; color: #FFFFFF;
}
.onoffswitch-inner:after {
    content: "OFF";
    padding-right: 10px;
    background-color: #F70A0A; color: #999999;
    text-align: right;
}
.onoffswitch-switch {
    display: block; width: 50px; margin: 12.5px;
    background: #FFFFFF;
    position: absolute; top: 0; bottom: 0;
    right: 121px;
    border: 2px solid #999999; border-radius: 50px;
    transition: all 0.3s ease-in 0s; 
}
.onoffswitch-checkbox:checked + .onoffswitch-label .onoffswitch-inner {
    margin-left: 0;
}
.onoffswitch-checkbox:checked + .onoffswitch-label .onoffswitch-switch {
    right: 0px; 
}
.center {
    margin-left:auto; 
    margin-right:auto;
    border: 0px;
}
h1 {
    color: #FFFFFF;
    font-family: sans-serif;
    font-weight: bold;
}
p {
    color: #FFFFFF;
    font-family: sans-serif;
    font-size: 20px;
    font-weight: bold;
}
</style>
</head>
<body>
<div id="cont" class="onoffswitch">
    <input type="checkbox" name="onoffswitch" class="onoffswitch-checkbox" id="myonoffswitch" checked>
    <label class="onoffswitch-label" for="myonoffswitch">
        <span class="onoffswitch-inner"></span>
        <span class="onoffswitch-switch"></span>
    </label>
</div>
</body>