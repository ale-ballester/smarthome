<div id="main" class="wrapper style1">
	<div class="container">
		<header class="major">
			<h2>Contactenos</h2>
		</header>
		<section style="text-align:center">
		    <ul class="icons">
		        <li><a href="#" class="icon alt fa-envelope"><span class="label">Email</span></a>&nbsp;&nbsp;&nbsp;clabcontrol@gmail.com</li>
        		<li><a href="#" class="icon alt fa-facebook"><span class="label">Facebook</span></a>&nbsp;&nbsp;&nbsp;Clab Control</li>
        		<li><a href="#" class="icon alt fa-phone"><span class="label">Phone</span></a>&nbsp;&nbsp;&nbsp;(011) 15 - 6360 - 4491</li>
        		<li><a href="#" class="icon alt fa-globe"><span class="label">Web</span></a>&nbsp;&nbsp;&nbsp;www.clabcontrol.com</li>
        	</ul>
		</section>
	</div>
</div>
<!-- End form -->