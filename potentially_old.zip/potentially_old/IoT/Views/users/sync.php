<?php

    echo $data;

?>