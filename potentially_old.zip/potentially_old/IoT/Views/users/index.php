<!-- Banner -->
<section id="banner">
	<div class="content">
		<span class="image"><img src="<?php echo URL; ?>Views/img/black-logo.png" alt="" /></span>
		<header>
			<h2>Tus objetos inteligentes</h2>
			<!-- <p>El futuro esta aqui.<br />
			Todos tus lugares, en tu <i>smarthome</i>.</p> -->
		</header>
	</div>
</section>

<!-- Footer -->
<footer id="footer">
	<ul class="copyright">
		<li>&copy; Untitled. All rights reserved.</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
	</ul>
</footer>