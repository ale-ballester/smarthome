<!-- Login form -->
<div id="main" class="wrapper style1">
	<div class="container">
		<header class="major">
			<h2>Vincule su nuevo dispositivo CLAB</h2>
		</header>
		<section>
			<form method="POST" action="">
				<div class="row uniform 50%">
					<div class="6u$ 12u$(xsmall)">
						<input type="text" name="id" id="id" value="" placeholder="ID" required />
					</div>
					<div class="6u 12u$(xsmall)">
						<input type="text" name="name" id="naem" value="" placeholder="Nombre" required />
					</div>
					<div class="12u$">
						<ul class="actions">
							<li><input type="submit" value="Vincular" class="special" /></li>
							<li><input type="reset" value="Reset" /></li>
						</ul>
					</div>
				</div>
			</form>
		</section>
	</div>
</div>
<!-- End form -->