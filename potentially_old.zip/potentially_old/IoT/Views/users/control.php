<script type="text/javascript" src="<?php echo URL; ?>Views/template/js/lib/Concurrent.Thread.js"></script>
<script type="text/javascript" src="<?php echo URL; ?>Views/template/js/control.js"></script>
<script type="text/javascript">
    function parallel() {
        setInterval(sync, 1000, "<?php echo URL . 'users' . DS . 'sync' . DS; ?>");
    }
    
    Concurrent.Thread.create(parallel);
</script>
<section id="four" class="wrapper style1 special fade-up" style="width:100%">
    <div class="container" style="width:100%">
        <div class="box alt" style="width:100%">
            <div class="row uniform" style="width:100%">
                    <?php 
                        $num = sizeof($data['id']);
                        for($i = 0; $i < $num; $i++) {
                    ?>
                <section class="2u 3u(small) 3u(xsmall)">
                    <h5 style="text-align:center"><?php echo $data['name'][$i]; ?></h5>
                    <!-- Action: <p id="<?php echo $data["id"][$i]; ?>Action" style="display:inline"><?php echo $data['obj'][$i]->getAction(); ?></p><br /> -->
                    <!-- Status: <p id="<?php echo $data["id"][$i]; ?>Status" style="display:inline"><?php echo $data['obj'][$i]->getStatus(); ?></p><br /> -->
                        <?php
                            if($data['type'][$i] == "digitalout"){
                                if ($data['obj'][$i]->getStatus() == 0){
                                    echo '<span id="' . $data['id'][$i] . '" devstat="0" type="button" class="clickableAwesomeFont" onclick="act(\'' . $data['id'][$i] . '\', \'' . URL . 'users' . DS . 'act' . DS . '\')">
                                    <i id="' . $data['id'][$i] . '-icon" class="fa fa-power-off fa-3x" aria-hidden="true"></i></span>';
                                } else {
                                    echo '<span id="' . $data['id'][$i] . '" devstat="255" type="button" class="clickableAwesomeFont" onclick="act(\'' . $data['id'][$i] . '\', \'' . URL . 'users' . DS . 'act' . DS . '\')">
                                    <i id="' . $data['id'][$i] . '-icon" class="fa fa-lightbulb-o fa-3x" aria-hidden="true"></i></span>';
                                }
                            }
                        ?>
                </section>
                <?php } ?>
                <section class="2u 3u(small) 3u(xsmall)">
                    <h5 style="text-align:center">Anadir</h5>
                    <span type="button" class="clickableAwesomeFont plus" onclick="window.location.href='<?php echo URL; ?>users/add_device'"><i class="fa fa-plus fa-3x" aria-hidden="true"></i></span>
                </section>
            </div>
        </div>
    </div>
</section>