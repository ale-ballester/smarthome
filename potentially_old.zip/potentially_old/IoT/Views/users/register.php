<!-- Register form -->
<div id="main" class="wrapper style1">
	<div class="container">
		<header class="major">
			<h2>Registrese en CLAB</h2>
		</header>
		<section>
			<form method="POST" action="">
				<div class="row uniform 50%">
					<div class="6u$ 12u$(xsmall)">
						<input type="text" name="name" id="name" value="" placeholder="Nombre completo" required />
					</div>
					<div class="6u$ 12u$(xsmall)">
						<input type="email" name="email" id="email" value="" placeholder="Email" required />
					</div>
					<div class="6u 12u$(xsmall)">
						<input type="password" name="pass1" id="password" value="" placeholder="Contrasena" required />
					</div>
					<div class="6u 12u$(xsmall)">
						<input type="password" name="pass2" id="password" value="" placeholder="Reescriba su contrasena" required />
					</div>
					<div class="12u$">
						<ul class="actions">
							<li><input type="submit" value="Registrarse" class="special" /></li>
							<li><input type="reset" value="Reset" /></li>
						</ul>
					</div>
				</div>
			</form>
		</section>
	</div>
</div>
<!-- End form -->