<!-- One -->
<section id="one" class="spotlight style1 bottom">
	<span class="image fit main"><img src="<?php echo URL; ?>Views/img/background.png" alt="" /></span>
	<div class="content">
		<div class="container">
			<div class="row">
				<div class="4u 12u$(medium)">
					<header>
						<h2>Adelantandose a lo que viene</h2>
						<p>El control a distancia y el IoT.</p>
					</header>
				</div>
				<div class="4u 12u$(medium)">
					<p>Interruptores? Llaves? Salir de la cama para apagar la luz? 
					Gastos innecesarios de energia? Cosas del pasado. El llamado 
					"Internet of Things" (Internet de las Cosas) llega para reolver incontables
					problemas cotidianos e incorporar las potencialidades de la tecnologia en el mundo
					en el que vivimos.</p>
				</div>
				<div class="4u$ 12u$(medium)">
					<p>Descubra todos los beneficios del IoT y la
					domotica de forma facil, sin las complicaciones que
					parecen caracterizar a los productos tecnologicos actuales.
					 CLAB le muestra como.</p>
				</div>
			</div>
		</div>
	</div>
	<!-- <a href="#two" class="goto-next scrolly">Next</a> -->
</section>