var opts = {
  lines: 7 // The number of lines to draw
, length: 9 // The length of each line
, width: 7 // The line thickness
, radius: 0 // The radius of the inner circle
, scale: 1 // Scales overall size of the spinner
, corners: 1 // Corner roundness (0..1)
, color: '#ffffff' // #rgb or #rrggbb or array of colors
, opacity: 0.25 // Opacity of the lines
, rotate: 0 // The rotation offset
, direction: 1 // 1: clockwise, -1: counterclockwise
, speed: 1 // Rounds per second
, trail: 69 // Afterglow percentage
, fps: 20 // Frames per second when using setTimeout() as a fallback for CSS
, zIndex: 2e9 // The z-index (defaults to 2000000000)
, className: 'spinner' // The CSS class to assign to the spinner
, top: '50%' // Top position relative to parent
, left: '50%' // Left position relative to parent
, shadow: false // Whether to render a shadow
, hwaccel: false // Whether to use hardware acceleration
, position: 'relative' // Element positioning
}

var target = "";
var spinner = {};

function act(dev, url){
    var state = document.getElementById(dev).getAttribute("devstat");
    target = document.getElementById(dev);
    spinner[dev] = new Spinner(opts).spin(target);
    setTimeout(function(){
        if (state == document.getElementById(dev).getAttribute("devstat")) {
            document.getElementById(dev).firstChild.innerHTML = "<i class='fa fa-times fa-2x' aria-hidden='true' style='color:red;position:absolute'></i>";
            setTimeout(function() {
                document.getElementById(dev).firstChild.innerHTML = "";
                spinner[dev].stop();
            }, 2000)
        }
    }, 30000);
    $(document).ready(function(){
        $.post(url,
        {
            device: dev
        }, function(data, status){
        });
    });
}

function sync(url) {
    $(document).ready(function(){
        $.post(url, {},
            function(data,status){
                var devices = data.split("\\");
                var rem = devices.splice(-1, 1);
                for (var i = 0;i<devices.length;i++) {
                    var deval = devices[i].split("=");
                    var devchar = deval[0].split(".");
                    var devid = devchar[0];
                    var type = devchar[1];
                    var value = deval[1];
                    var statid = devid.concat("Status");
                    if(type == "digitalout" && value != document.getElementById(devid).getAttribute("devstat")) {
                        if(value == "255") {
                            document.getElementById(devid).innerHTML = "<i class='fa fa-lightbulb-o fa-3x' aria-hidden='true'></i>";
                            // document.getElementById(devid).innerHTML = value;
                            // document.getElementById(devid).className = "w3-btn-floating-large w3-green";
                            // document.getElementById(devid).innerHTML = "ON";
                            document.getElementById(devid).setAttribute("devstat", "255");
                            spinner[devid].stop();
                        }
                        if(value == "0") {
                            document.getElementById(devid).innerHTML = "<i class='fa fa-power-off fa-3x' aria-hidden='true'></i>";
                            // document.getElementById(devid).innerHTML = value;
                            // document.getElementById(devid).className = "w3-btn-floating-large w3-red";
                            // document.getElementById(devid).innerHTML = "OFF";
                            document.getElementById(devid).setAttribute("devstat", "0");
                            spinner[devid].stop();
                        }    
                    }
                }
            }
        );
    });
}