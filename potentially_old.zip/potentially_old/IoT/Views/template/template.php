<?php namespace Views;
    
    $template = new Template($request->getMethod());

    class Template {
        
        public function __construct($name)
        {
        	session_start();
            
?>
    <!DOCTYPE HTML>
	<!--
		Landed by HTML5 UP
		html5up.net | @ajlkn
		Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
	-->
	<html>
		<head>
			<title><?php echo ucwords($name); ?></title>
			<meta charset="utf-8" />
			<meta name="viewport" content="width=device-width, initial-scale=1" />
			<!--[if lte IE 8]><script src="<?php echo URL; ?>Views/template/assets/js/ie/html5shiv.js"></script><![endif]-->
			<link rel="stylesheet" href="<?php echo URL; ?>Views/template/assets/css/main.css" />
			<!--[if lte IE 9]><link rel="stylesheet" href="<?php echo URL; ?>Views/template/assets/css/ie9.css" /><![endif]-->
			<!--[if lte IE 8]><link rel="stylesheet" href="<?php echo URL; ?>Views/template/assets/css/ie8.css" /><![endif]-->
			<link rel="stylesheet" href="<?php echo URL; ?>Views/template/css/general.css" type="text/css" />
		</head>
		<body class="landing">
			<div id="page-wrapper">
	
				<!-- Header -->
					<header id="header">
						<h1 id="logo"><a href="<?php echo URL; ?>">CLAB</a></h1>
						<!-- <span id="logo"><a href="<?php echo URL; ?>"><span id="clab"><img src="<?php echo URL; ?>Views/img/black-logo.jpg" alt="" /></span></a></span> -->
						<nav id="nav">
							<ul>
								<li><a href="<?php echo URL; ?>">Home</a></li>
								<li><a href="<?php echo URL; ?>users/contact">Contacto</a></li>
								<?php
								if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
									echo '
									<li style="-moz-user-select: none; cursor: pointer; white-space: nowrap; opacity: 1;" class="opener"><a href="' . URL . 'users/control">' . $_SESSION['name'] . '</a>
										<ul style="-moz-user-select: none; display: none; position: absolute;" class="">
											<li style="white-space: nowrap;"><a href="' . URL .'" style="display: block;">Configuracion</a></li>
										</ul>
									</li>
									<li><a href="' . URL . 'users/logout" class="button special">Cerrar Sesion</a></li>
									';
								} else {
									echo '
									<li><a href="' . URL . 'users/login" class="button">Iniciar Sesion</a></li>
									<li><a href="' . URL . 'users/register" class="button">Registrarse</a></li>
									';
								}
								?>
							</ul>
						</nav>
					</header>
            
<?php
        }
        
        public function __destruct() {
?>					
                </div>
                <!-- Scripts -->
				<script src="<?php echo URL; ?>Views/template/assets/js/jquery.min.js"></script>
				<script src="<?php echo URL; ?>Views/template/assets/js/jquery.scrolly.min.js"></script>
				<script src="<?php echo URL; ?>Views/template/assets/js/jquery.dropotron.min.js"></script>
				<script src="<?php echo URL; ?>Views/template/assets/js/jquery.scrollex.min.js"></script>
				<script src="<?php echo URL; ?>Views/template/assets/js/skel.min.js"></script>
				<script src="<?php echo URL; ?>Views/template/assets/js/util.js"></script>
	            <script src="<?php echo URL; ?>Views/template/js/lib/spin.min.js"></script>
				<!--[if lte IE 8]><script src="<?php echo URL; ?>Views/template/assets/js/ie/respond.min.js"></script><![endif]-->
				<script src="<?php echo URL; ?>Views/template/assets/js/main.js"></script>
	
		</body>
	</html>
<?php
        }
    }

?>