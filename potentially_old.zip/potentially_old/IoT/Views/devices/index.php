<?php namespace Views;

    echo $data;

?>