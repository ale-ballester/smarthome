<?php

    require_once("Config/Autoload.php");
    Config\Autoload::run();
    Config\Router::run(new Config\Request());

?>