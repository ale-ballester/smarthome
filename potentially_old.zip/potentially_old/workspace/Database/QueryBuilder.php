<?php namespace Database;

class QueryBuilder extends Connection
{   
    public function __construct()
    {
        
    }

    public function insert($data)
    {
        
    }
}

?>