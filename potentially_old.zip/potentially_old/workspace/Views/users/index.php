        <div class="container">
            <div class="row">
                <div class="col-md-offset-5 col-md-3">
                    <div class="form-login">
                    <h4>Be home. Everywhere.</h4>
                    <form class="form-horizontal" action="" method="POST">
                        <input type="text" name="username" class="form-control input-sm chat-input" placeholder="username" required />
                        <input type="password" name="password" class="form-control input-sm chat-input" placeholder="password" required />
                        <div class="wrapper">
                        <span class="group-btn">     
                            <button class="btn btn-success" type="submit">Log in</button>
                            <a href="<?php echo URL; ?>users/register/" class="btn btn-info">Register</a>
                        </span>
                        </div>
                    </form>
                    </div>
                </div>
            </div>
        </div>
        